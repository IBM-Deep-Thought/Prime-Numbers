Hello, welcome to the infinite generator of prime numbers!
This python package generates infinite very big python numbers, created by fmuror02 https://github.com/fmuror02
What are you waiting for?! Read the SETUP instructions and start the program! :)
